package com.cab.driver;

import com.cab.common.Rating;

public class Driver extends Rating{
	
	private boolean isOnline;

	public Driver(String id) {
		super(id);
		this.isOnline = true;
	}
	
	
	
	

}
